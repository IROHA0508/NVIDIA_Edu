import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rc('font', family='Malgun Gothic')
plt.rcParams['axes.unicode_minus'] = False


result_list = []

for i in range(1, 10):
    filename = "Line%d.csv" % i
    df = pd.read_csv(filename, encoding="cp949")

    max_idx = df["승차총승객수"].idxmax()

    valid_df = df[df["하차총승객수"] >= 100]
    
    if not valid_df.empty:
        min_idx = valid_df["하차총승객수"].idxmin()
        min_station = valid_df.loc[min_idx, "역명"]
        min_passengers = valid_df.loc[min_idx, "하차총승객수"]
    else:
  
        min_station = "데이터 없음"
        min_passengers = None

    result_list.append({
        "호선": "%d호선" % i,
        "승차 1위 역": df.loc[max_idx, "역명"],
        "최대 승차인원": df.loc[max_idx, "승차총승객수"],
        "하차 꼴찌 역(100명 이상)": min_station,
        "최소 하차인원": min_passengers
    })

summary_df = pd.DataFrame(result_list)
print(summary_df)

fig, (ax1, ax2) = plt.subplots(nrows=2, figsize=(10, 10))

sns.barplot(data=summary_df, x="호선", y="최대 승차인원", ax=ax1, color="royalblue")
ax1.set_title("각 호선별 최대 승차인원 역", fontsize=14, fontweight='bold')

sns.barplot(data=summary_df, x="호선", y="최소 하차인원", ax=ax2, color="salmon")
ax2.set_title("각 호선별 최소 하차인원 역 (100명 이상)", fontsize=14, fontweight='bold')

plt.tight_layout()
plt.show()